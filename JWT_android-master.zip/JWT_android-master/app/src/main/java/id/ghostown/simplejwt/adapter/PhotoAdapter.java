package id.ghostown.simplejwt.adapter;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.github.javiersantos.bottomdialogs.BottomDialog;
import com.jakewharton.picasso.OkHttp3Downloader;
import com.orhanobut.hawk.Hawk;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.List;

import id.ghostown.simplejwt.R;
import id.ghostown.simplejwt.Constant;
import id.ghostown.simplejwt.Utils;
import id.ghostown.simplejwt.model.BaseResponse;
import id.ghostown.simplejwt.model.Like;
import id.ghostown.simplejwt.model.Photo;
import id.ghostown.simplejwt.model.User;
import id.ghostown.simplejwt.service.Api;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by iamnubs (Ghuniyu F R) on 31/07/2017.
 */

public class PhotoAdapter extends BaseQuickAdapter<Photo, BaseViewHolder> {


    public PhotoAdapter(int layoutResId, @Nullable List<Photo> photo) {
        super(layoutResId, photo);
    }

    @Override
    protected void convert(BaseViewHolder helper, final Photo item) {
        final ImageView imageView = helper.getView(R.id.ivPhoto);
        final TextView textView = helper.getView(R.id.tvApproval);

        helper.setText(R.id.date, item.createdAt);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = Hawk.get(Constant.USER);
                boolean hasLike = false;
                List<Like> like = item.likes;
                for (Like i : like) {
                    if (i.username.equals(user.username))
                        hasLike = true;
                }
                if (hasLike) {
                    Toast.makeText(mContext, "You Already Approve this Picture", Toast.LENGTH_SHORT).show();
                } else if (user.role.id == 2) {
                    new BottomDialog.Builder(mContext)
                            .setTitle("Confirmation!")
                            .setContent("Are sure want to Approve this photo?.")
                            .setPositiveText("Yes")
                            .setPositiveBackgroundColorResource(R.color.colorPrimary)
                            .setPositiveTextColorResource(android.R.color.white)
                            .onPositive(new BottomDialog.ButtonCallback() {
                                @Override
                                public void onClick(BottomDialog dialog) {
                                    Api.getService().like(item.id).enqueue(new Callback<BaseResponse>() {
                                        @Override
                                        public void onResponse(Call<BaseResponse> call, retrofit2.Response<BaseResponse> response) {
                                            if (response.isSuccessful()) {
                                                Toast.makeText(mContext, Constant.TAG_SUCCESS, Toast.LENGTH_SHORT).show();
                                                Intent intent = ((Activity) mContext).getIntent();
                                                ((Activity) mContext).finish();
                                                mContext.startActivity(intent);
                                            }
                                        }

                                        @Override
                                        public void onFailure(Call<BaseResponse> call, Throwable t) {
                                            Toast.makeText(mContext, Constant.TAG_NETWORK, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }).show();
                }
            }
        });
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setMaxLines(textView.getMaxLines() == 1 ? 3 : 1);
            }
        });

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request newRequest = chain.request().newBuilder()
                                .addHeader("Authorization", Hawk.get(Constant.TOKEN).toString())
                                .build();
                        return chain.proceed(newRequest);
                    }
                })
                .build();

        Picasso picasso = new Picasso.Builder(mContext)
                .downloader(new OkHttp3Downloader(client))
                .build();

        picasso.load(Constant.BASE_URL + "api/photo/file/" + item.id).into(imageView);
        Log.e("Photo", Constant.BASE_URL + "api/photo/file/" + item.id);
        List<Like> likes = item.likes;

        String liker = "Approved by  ";
        for (Like i : likes) {
            liker += i.username + ", ";
        }

        if (liker.equals("Approved by  ")) {
            helper.setVisible(R.id.ivCheck, false);
            helper.setVisible(R.id.tvApproval, false);
        } else
            liker = liker.substring(0, liker.length() - 2);

        helper.setText(R.id.tvApproval, liker);
    }
}
