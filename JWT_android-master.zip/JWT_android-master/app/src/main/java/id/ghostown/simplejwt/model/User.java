package id.ghostown.simplejwt.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by iamnubs (Ghuniyu F R) on 31/07/2017.
 */

public class User {
    @SerializedName("id")
    @Expose
    public int id;

    @SerializedName("username")
    @Expose
    public String username;

    @SerializedName("created_at")
    @Expose
    public String createdAt;

    @SerializedName("updated_at")
    @Expose
    public String updatedAt;

    @SerializedName("role_id")
    @Expose
    public int roleId;

    @SerializedName("role")
    @Expose
    public Role role;
}
