package id.ghostown.simplejwt.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by iamnubs (Ghuniyu F R) on 31/07/2017.
 */

public class Data {
    @SerializedName("token")
    @Expose
    public String token;

    @SerializedName("user")
    @Expose
    public User user;

    @SerializedName("photo")
    @Expose
    public Photo photo;

    @SerializedName("photos")
    @Expose
    public List<Photo> photos = null;
}
