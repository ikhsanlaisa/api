package id.ghostown.simplejwt.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.style.Wave;
import com.orhanobut.hawk.Hawk;

import butterknife.BindView;
import butterknife.OnClick;
import id.ghostown.simplejwt.R;
import id.ghostown.simplejwt.Constant;
import id.ghostown.simplejwt.model.BaseResponse;
import id.ghostown.simplejwt.service.Api;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by iamnubs on 31/07/2017.
 */

public class LoginActivity extends BaseActivity {

    @BindView(R.id.ivLoading)
    ImageView ivLoading;
    @BindView(R.id.login)
    TextView login;
    @BindView(R.id.username)
    TextView username;
    @BindView(R.id.password)
    TextView password;

    Wave wave;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wave = new Wave();
    }

    @OnClick(R.id.login)
    void login() {
        wave.setColor(getResources().getColor(R.color.colorWhite));
        ivLoading.setImageDrawable(wave);
        ivLoading.setVisibility(View.VISIBLE);
        wave.start();

        Api.getService().login(username.getText().toString(), password.getText().toString()).enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful()) {

                    Toast.makeText(LoginActivity.this, Constant.TAG_SUCCESS, Toast.LENGTH_SHORT).show();
                    Hawk.put(Constant.DATA, response.body().data);
                    Hawk.put(Constant.TOKEN, "Bearer " + response.body().data.token);
                    Hawk.put(Constant.USER, response.body().data.user);
                    Hawk.put(Constant.ROLE, response.body().data.user.role);
                    startActivity(new Intent(LoginActivity.this, ListsActivity.class));

                } else if (response.code() == 401) {
                    Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();

                }
                ivLoading.setVisibility(View.GONE);
                wave.stop();
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                Log.e("Failure", t.getMessage());
                Toast.makeText(LoginActivity.this, Constant.TAG_NETWORK, Toast.LENGTH_SHORT).show();
                ivLoading.setVisibility(View.GONE);
                wave.stop();
            }
        });
    }

    @Override
    public int getContent() {
        return R.layout.activity_login;
    }
}
