package id.ghostown.simplejwt.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by iamnubs (Ghuniyu F R) on 01/08/2017.
 */

public class Role {
    @SerializedName("id")
    @Expose
    public int id;

    @SerializedName("name")
    @Expose
    public String name;
}
