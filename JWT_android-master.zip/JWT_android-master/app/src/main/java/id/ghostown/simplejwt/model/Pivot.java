package id.ghostown.simplejwt.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by iamnubs (Ghuniyu F R) on 01/08/2017.
 */

public class Pivot {
    @SerializedName("photo_id")
    @Expose
    public int photoId;

    @SerializedName("user_id")
    @Expose
    public int userId;
}
