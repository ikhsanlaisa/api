package id.ghostown.simplejwt.service;

import java.util.List;

import id.ghostown.simplejwt.model.BaseResponse;
import id.ghostown.simplejwt.model.Photo;
import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

/**
 * Created by iamnubs on 5/15/17.
 */

public interface Service {
    @Multipart
    @POST("api/photo")
    Call<BaseResponse> upload(@Part MultipartBody.Part photo);

    @FormUrlEncoded
    @POST("api/login")
    Call<BaseResponse> login(@Field("username") String username, @Field("password") String password);

    @GET("api/photo")
    Call<BaseResponse> photos();

    @GET("api/photo/like/{id}")
    Call<BaseResponse> like(@Path("id") int id);

}
