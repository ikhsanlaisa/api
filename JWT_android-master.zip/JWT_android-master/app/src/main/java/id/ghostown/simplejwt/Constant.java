package id.ghostown.simplejwt;

/**
 * Created by iamnubs (Ghuniyu F R) on 31/07/2017.
 */

public class Constant {
    public static final String BASE_URL = "http://emi.alvus.id/";
    public static final String DATA = "data";
    public static final String USER = "user";
    public static final String ROLE = "role";
    public static final String TOKEN = "jwt_token";
    public static final String TAG_SUCCESS = "Success";
    public static final String TAG_NETWORK = "Please Check your Internet Connection";
}
