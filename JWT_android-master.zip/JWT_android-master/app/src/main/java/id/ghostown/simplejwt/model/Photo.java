package id.ghostown.simplejwt.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by iamnubs (Ghuniyu F R) on 01/08/2017.
 */

public class Photo {
    @SerializedName("id")
    @Expose
    public int id;

    @SerializedName("path")
    @Expose
    public String path;

    @SerializedName("user_id")
    @Expose
    public int userId;

    @SerializedName("created_at")
    @Expose
    public String createdAt;

    @SerializedName("likes")
    @Expose
    public List<Like> likes = null;
}
