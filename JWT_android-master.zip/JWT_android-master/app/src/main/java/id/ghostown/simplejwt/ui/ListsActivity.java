package id.ghostown.simplejwt.ui;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.style.Wave;
import com.orhanobut.hawk.Hawk;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import id.ghostown.simplejwt.Constant;
import id.ghostown.simplejwt.R;
import id.ghostown.simplejwt.adapter.PhotoAdapter;
import id.ghostown.simplejwt.model.BaseResponse;
import id.ghostown.simplejwt.model.Photo;
import id.ghostown.simplejwt.model.User;
import id.ghostown.simplejwt.service.Api;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by iamnubs (Ghuniyu F R) on 31/07/2017.
 */

public class ListsActivity extends BaseActivity {
    final static int TAG_EASY = 1708;

    List<Photo> photoList;

    @BindView(R.id.rlUpload)
    RelativeLayout rlUpload;

    @BindView(R.id.ivStartup)
    ImageView ivStartup;

    @BindView(R.id.ivLoading)
    ImageView ivLoading;

    @BindView(R.id.no_data)
    TextView no_data;

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    final Wave wave = new Wave();
    final Wave waveUpload = new Wave();

    LinearLayoutManager layoutManager;

    PhotoAdapter adapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        verifyStoragePermissions(this);

        wave.setColor(getResources().getColor(R.color.colorAccent));
        waveUpload.setColor(getResources().getColor(R.color.colorWhite));

        ivLoading.setImageDrawable(waveUpload);

        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        loadContent();

        User user = Hawk.get(Constant.USER);
        Log.e("Data User", user.username + " - " + user.roleId + " - " + user.role.name);
        if (user.role.id == 1)
            rlUpload.setVisibility(View.VISIBLE);
    }

    private void loadContent() {
        ivStartup.setImageDrawable(wave);
        wave.start();
        Api.getService().photos().enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful()) {
                    photoList = response.body().data.photos;
                    ivStartup.setVisibility(View.GONE);
                    wave.stop();
                    if (photoList.size() == 0) {
                        no_data.setVisibility(View.VISIBLE);
                    }
                    adapter = new PhotoAdapter(R.layout.row_photo, photoList);
                    recyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                Toast.makeText(ListsActivity.this, Constant.TAG_NETWORK, Toast.LENGTH_SHORT).show();
                ivStartup.setVisibility(View.GONE);
                wave.stop();
            }
        });
    }

    @OnClick(R.id.upload)
    void uploadImage() {
        EasyImage.openChooserWithGallery(ListsActivity.this, "Select Image From", TAG_EASY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePickerError(Exception e, EasyImage.ImageSource source, int type) {

            }

            @Override
            public void onImagePicked(File imageFile, EasyImage.ImageSource source, int type) {
                upload(imageFile);
            }

            @Override
            public void onCanceled(EasyImage.ImageSource source, int type) {
                if (source == EasyImage.ImageSource.CAMERA) {
                    File photoFile = EasyImage.lastlyTakenButCanceledPhoto(ListsActivity.this);
                    if (photoFile != null) photoFile.delete();
                }
            }
        });
    }

    private void upload(File file) {
        waveUpload.start();
        ivLoading.setVisibility(View.VISIBLE);
        MultipartBody.Part partImage = MultipartBody.Part.createFormData("photo", file.getName(), RequestBody.create(MediaType.parse("image/*"), file));
        Api.getService().upload(partImage).enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(ListsActivity.this, "Upload Successful", Toast.LENGTH_SHORT).show();
                    waveUpload.stop();
                    ivLoading.setVisibility(View.GONE);

                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);

                } else {
                    Toast.makeText(ListsActivity.this, "Failed to Upload Photo", Toast.LENGTH_SHORT).show();
                    waveUpload.stop();
                    ivLoading.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                Toast.makeText(ListsActivity.this, Constant.TAG_NETWORK, Toast.LENGTH_SHORT).show();
                waveUpload.stop();
                ivLoading.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public int getContent() {
        return R.layout.activity_lists;
    }

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    public static void verifyStoragePermissions(Activity activity) {
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Hawk.deleteAll();
        finish();
    }
}
